#include<stdio.h>

//int a=1;
//extern void add(void);
int a;
void add()
{
	int b=2,c;
	c=a+b;
	printf("%d\n",c);
}
