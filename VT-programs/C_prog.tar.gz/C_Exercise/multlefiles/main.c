#include<stdio.h>
extern void add(void);
int a=1;
//int add()
//{
//}
int main()
{
	add();
	return 0;	
}
