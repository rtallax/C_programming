// arr[]={VT is HYD,VT in BLR,VTX in Noida}

#include<stdio.h>

int main()
{
	int i ;
	char arr[100]={"VT is HYD","VT in BLR","VTX in Noida"};
	for(i=0;i<3;i++)
	{
		printf("%s\n",arr[i]);
	}
}	

