#include<stdio.h>

int main()
{
	printf("char=%d shortint=%d int=%d longint=%d double=%d long=%d longdouble=%d\n",sizeof(char),sizeof(short int),sizeof(int),sizeof(long int),sizeof(double),sizeof(long),sizeof(long double));
return 0;
}
