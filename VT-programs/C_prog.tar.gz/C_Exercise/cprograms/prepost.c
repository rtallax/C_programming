#include<stdio.h>
int main()
{
	int y=3,z;
	z=(--y)+(y=10);
	printf("%d\n",z);
}
	
