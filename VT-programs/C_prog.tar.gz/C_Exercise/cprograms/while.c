#include<stdio.h>
int main()
{
	int a = -1;
	while(a)
	{
		if(a)
			printf("SUCCESSFUL\n");
		else
			printf("FAIL\n");
		a++;
	}
	return 0;
	
}
