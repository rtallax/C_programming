#include<stdio.h>
int main()
{;
	char *a;
	printf("Enter the value\n");
	gets(a);
	printf("%s\n",a);
	return 0;
}
