
int main()
{
	(void *)fun(int ,int);
	
