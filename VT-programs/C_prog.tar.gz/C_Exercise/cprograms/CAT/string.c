#include<stdio.h>
int main()
{
 char *str; 
 str = "GfG";
 *(str+1) = 'n';
 getchar();
 return 0;
}
