#include<stdio.h>
int main()
{
	char c[]="#votary";
	char *p = c;
	printf("%s %d",p,'ss');
	return 0;
}
