#include <stdio.h>

#define int char

int main()
{
	int a=65;
	printf("%d",sizeof(a));
}
