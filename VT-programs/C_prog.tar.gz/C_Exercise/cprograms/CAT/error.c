#include<stdio.h>

int main()
{
	//int a=- -2;
	printf("\nhi");
	printf("\bhello");
	//printf("\rbye");

}
