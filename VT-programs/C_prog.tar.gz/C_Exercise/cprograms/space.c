#include <stdio.h>
int main()
{
    int pos = 14;
    float data = 1.2;
    printf("%*f",pos,data);
    return 0;
}
