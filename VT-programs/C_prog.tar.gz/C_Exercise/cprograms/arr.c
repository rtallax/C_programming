#include<stdio.h>
int main()
{
	int a[5]={1,2,3,4,5};
	printf("%d\t",a[1]);
	a++;	
	printf("%d\n",a[3]);
}
