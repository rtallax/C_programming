#include<stdio.h>
struct name
{
	//double c;
	//short b;
	//char d;
	char e;
	short d;
	char x;
	int c;
};

int main()
{
	printf("size=%d\n",sizeof(struct name));
	return 0;
}

