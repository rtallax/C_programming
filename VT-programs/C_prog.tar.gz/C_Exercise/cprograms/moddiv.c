#include<stdio.h>
int main()
{
	int a;
	a=5.0%2;
	printf("%d\n",a);
	return 0;
}
