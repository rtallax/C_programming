#include <stdio.h>
#include <string.h>

int  main()
{
	char *str[]={"flower","flow","flaw"};
	int i,j;
	//while(str[0]!='\0')
		printf("%s\n",str[0]);
		printf("%s\n",str[1]);
		printf("%s\n",str[2]);
		printf("%d\n",strlen(str[0]));		
		printf("%d\n",strlen(str[1]));		
		printf("%d\n",strlen(str[2]));	
	for(i=0;i<3;i++)
	{
		for(j=0;j<4;j++)
		{
			if(str[i][j]
		}
			//printf("%c\n",str[i][j]);
	}
}
