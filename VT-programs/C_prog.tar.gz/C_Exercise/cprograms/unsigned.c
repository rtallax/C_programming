#include <stdio.h>
int main(void)
{
	int var;
	for(var = -3 ; var < sizeof(int) ; var++)
	{
		printf("Hello Aticleworld\n");
	}
	return 0;
}
