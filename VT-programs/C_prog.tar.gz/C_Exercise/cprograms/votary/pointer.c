#include<stdio.h>
int main()
{
	int *p=2;
	printf("p=%d\n",p);
	printf("star p=%p\n",*p);
	printf("add p=%p\n",&p);
}
