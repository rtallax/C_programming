#include<stdio.h>
int main()
{
        if(printf("Hello"))
                printf("TRUE\n");
        else
                printf("FALSE\n");
        return 0;
}
