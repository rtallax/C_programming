#include<stdio.h>
int main()
{
	int a;
	a=printf("%d",a);
	printf("\n%d\n",a);
	return 0;
}
