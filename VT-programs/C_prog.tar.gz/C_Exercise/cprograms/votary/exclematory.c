#include<stdio.h>
int main()
{
	if(!printf("Votary "))
	{
		printf("soft ");
	}
	else
	{
		printf("tech");
	}
}
