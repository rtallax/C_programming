#include<stdio.h>
int main()
{
	printf("MAIN\n");
	main();
	main();
}
