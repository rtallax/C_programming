 #include <stdio.h> 
void main() 
{ 
	int a = 5 * 3 + 2 - 4; 
	printf("%d", a); 
}
