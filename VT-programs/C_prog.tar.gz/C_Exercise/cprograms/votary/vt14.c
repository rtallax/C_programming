 #include <stdio.h> 
int main() 
{ 
	int *p = 2; 
	int *q = 3; 
	//int c=*p+*q;
	printf("%d", p+q); 
}
