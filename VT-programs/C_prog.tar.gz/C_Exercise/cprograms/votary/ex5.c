#include <stdio.h> 
int main() 
{ 
    int a; 
    a = 1, 2, 3; // Evaluated as (a = 1), 2, 3 
    printf("%d", a); 
    return 0; 
}
