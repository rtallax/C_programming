#include<stdio.h>
int main()
{
	int i=10;
	printf("%d %d\n",i,++i);
}
