 #include <stdio.h> 
void main() 
{ 
int a = 5 * 3 % 6 - 8 + 3; 
printf("%d", a); 
}
