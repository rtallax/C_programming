#include <stdio.h> 
void main() 
{ 
	double b = 3 % 0 * 1 - 4 / 2; 
	printf("%lf", b); 
}
