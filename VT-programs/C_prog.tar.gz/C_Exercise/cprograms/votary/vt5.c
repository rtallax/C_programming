#include <stdio.h> 
int main() 
{ 
int a = 1; 
switch (a)
{ 
case 1: printf("%d", a); 
case 2: printf("%d", a); 
case 3: printf("%d", a); 
default: printf("%d", a); 
}
}
