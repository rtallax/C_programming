#include<stdio.h> 
int main() 
{ 
	char *s = "Fine"; 
	*s = 'N'; 
	printf("%s", s); 
}
