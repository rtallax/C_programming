#include <stdio.h>
int main()
{
    int x = -30;
    x = x >> 1;
    printf("%d\n", x);
}
