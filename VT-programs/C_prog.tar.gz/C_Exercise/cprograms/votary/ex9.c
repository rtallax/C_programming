#include<stdio.h>
int main()
{
	int i;
	for(i==1;i<=3;i++)
		printf("Hello:\n");
	return 0;
}
