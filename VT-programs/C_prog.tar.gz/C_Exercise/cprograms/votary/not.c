#include<stdio.h> 
int main() 
{ 
int i=10; 
i=!i>14; 
printf("i=%d",i);
} 
