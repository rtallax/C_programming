#include<stdio.h>
int main()
{
	int a,b=1;
	a=b%2;
	printf("val=%d\n",a);
}
	
