#include<stdio.h>
int main()
{
	unsigned int i=10;
	while(i-- >=0)
	printf("%d ",i);
	return 0;
}
