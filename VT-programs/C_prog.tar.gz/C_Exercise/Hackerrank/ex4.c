#include<stdio.h>

int main()
{
int c=011 || 0X10;
printf("%d",c);
return 0;
}
