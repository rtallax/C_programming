#include<stdio.h>
int main()
{
	enum { orange=5, banana=4, peach};
	printf("peach=%d\n",peach);
}
