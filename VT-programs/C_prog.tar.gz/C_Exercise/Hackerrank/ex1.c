#include<stdio.h>

int main()
{
	int i=10,j;
	//j=!i<14;
//	printf("j=%d\n",j);
	i=!i>14;
	printf("i=%d",i);
}
