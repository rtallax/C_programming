#include<stdio.h>

int main()
{
	int  a=10;
//	printf("Enter the key\n");
//	scanf("%d",&a);
	a=a*a;
	printf("value=%d\n",a);	
}
