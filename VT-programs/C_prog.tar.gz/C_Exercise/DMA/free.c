#include<stdio.h>
#include<stdlib.h>

int main()
{
        int *ptr ;
        ptr=(int *)malloc(sizeof(int));
        printf("Enter the Elements of array\n");
        //free(ptr);
        return 0;
}
