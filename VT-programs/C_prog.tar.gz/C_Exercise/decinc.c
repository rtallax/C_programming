#include <stdio.h> 
int main() 
{ 
	int i=5; 
	printf("%d %d %d %d %d\n",i++,i--,++i,--i,i); 
}
//4 5 5 5 5
