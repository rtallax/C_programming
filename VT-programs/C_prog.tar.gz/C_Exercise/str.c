#include<stdio.h>

struct name
{
	int a;
	//char e;
	short b;
	char c;
	char e;
};
int main()
{
	printf("struct =%d\n",sizeof(struct name));
	return 0;
}
	
