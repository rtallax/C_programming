#include<stdio.h>

#define square(x) x*x
int main()
{
	printf("%d\n",square(4));
	int x=3;
	printf("%d\n",square(++x));
	return 0;
}
