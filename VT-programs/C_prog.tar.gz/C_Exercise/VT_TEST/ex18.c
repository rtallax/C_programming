#include <stdio.h> 
int main() 
{ 
	int a = 1; 
	switch (a) 
	{ 
		case a: printf("Case A "); 
		default: printf("Default"); 
	} 
}
