#include <stdio.h> 
void main() 
{ 
	int a = 5, b = -7, c = 0, d; 
	d = ++a && ++b || ++c; 
	printf("\n%d%d%d%d\n", a, b, c, d); 
}
