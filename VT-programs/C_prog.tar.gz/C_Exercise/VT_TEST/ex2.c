#include <stdio.h> 
void main() 
{ 
char *s = "hello"; 
//char *p = s; 
s = "h" ;
//printf("%c%c\t%c\n", *p,*(p+1), s[1]); 
printf("%c\n", *s); 
}
