#define display(text) printf(#text "@") 
int main() 
{ 
display(hello.); 
display(good morning!); 
}
