#include <stdio.h> 
int main() 
{ 
	int i = 10, j = 3; 
	printf("%d %d %d", i, j); 
}
